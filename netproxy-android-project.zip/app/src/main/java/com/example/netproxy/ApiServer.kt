package com.example.netproxy

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class ApiServer(port: Int, private val proxy: ProxyServer, private val ctx: Context): NanoHTTPD(port) {
    init { this.socketTimeout = 5000 }
    override fun serve(session: IHTTPSession?): Response {
        val uri = session?.uri ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, "application/json", "{\"ok\":false}\n")
        return when (uri) {
            "/proxy" -> {
                val obj = JSONObject()
                obj.put("proxy", "127.0.0.1:8080")
                newFixedLengthResponse(Response.Status.OK, "application/json", obj.toString())
            }
            "/status" -> {
                val obj = JSONObject()
                obj.put("proxy_running", proxy.isRunning())
                newFixedLengthResponse(Response.Status.OK, "application/json", obj.toString())
            }
            "/device" -> {
                val obj = JSONObject()
                obj.put("os", android.os.Build.VERSION.RELEASE)
                obj.put("model", android.os.Build.MODEL)
                newFixedLengthResponse(Response.Status.OK, "application/json", obj.toString())
            }
            "/reset" -> {
                // best-effort: instruct client to open settings
                val obj = JSONObject()
                obj.put("result", "open_settings")
                newFixedLengthResponse(Response.Status.OK, "application/json", obj.toString())
            }
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        }
    }
}
