package com.example.netproxy

import java.io.InputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class ProxyServer(private val port: Int) {
    private var serverSocket: ServerSocket? = null
    private var running = false

    fun start() {
        if (running) return
        running = true
        thread {
            serverSocket = ServerSocket()
            serverSocket!!.reuseAddress = true
            serverSocket!!.bind(InetSocketAddress(port))
            while (running) {
                try {
                    val client = serverSocket!!.accept()
                    handleClient(client)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    fun isRunning(): Boolean = running

    fun stop() {
        running = false
        try { serverSocket?.close() } catch (e: Exception) {}
    }

    private fun handleClient(client: Socket) {
        thread {
            try {
                val input = client.getInputStream()
                val first = readLineFromStream(input) ?: run { client.close(); return@thread }
                if (first.startsWith("CONNECT ")) {
                    val parts = first.split(' ')
                    val hostPort = parts[1]
                    val hp = hostPort.split(':')
                    val host = hp[0]
                    val port = if (hp.size > 1) hp[1].toInt() else 443
                    val server = Socket()
                    server.connect(InetSocketAddress(host, port), 5000)
                    val out = client.getOutputStream()
                    out.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                    forwardStreams(server.getInputStream(), client.getOutputStream())
                    forwardStreams(client.getInputStream(), server.getOutputStream())
                } else {
                    // very basic HTTP forward (no chunked/complex handling)
                    val parts = first.split(' ')
                    val method = parts[0]
                    val path = parts[1]
                    val hostHeader = extractHostFromHeaders(input, first)
                    val hostParts = hostHeader.split(':')
                    val host = hostParts[0]
                    val port = if (hostParts.size>1) hostParts[1].toInt() else 80
                    val server = Socket()
                    server.connect(InetSocketAddress(host, port), 5000)
                    val out = server.getOutputStream()
                    out.write((first + "\r\n").toByteArray())
                    // forward remaining incoming bytes
                    forwardStreams(input, out)
                    // forward server response back to client
                    forwardStreams(server.getInputStream(), client.getOutputStream())
                }
            } catch (e: Exception) {
                try { client.close() } catch(_:Exception) {}
            }
        }
    }

    private fun readLineFromStream(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return null
            if (b == '\n'.code) break
            if (b == '\r'.code) continue
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun forwardStreams(src: InputStream, dest: java.io.OutputStream) {
        thread {
            try {
                val buf = ByteArray(8192)
                var read = src.read(buf)
                while (read > 0) {
                    dest.write(buf, 0, read)
                    dest.flush()
                    read = src.read(buf)
                }
            } catch (_: Exception) {}
        }
    }

    private fun extractHostFromHeaders(input: InputStream, firstLine: String): String {
        // naive: read headers until blank line and find Host:
        val headers = StringBuilder()
        while (true) {
            val line = readLineFromStream(input) ?: break
            if (line.isBlank()) break
            headers.append(line).append("\n")
        }
        val regex = Regex("(?i)Host: (.+)")
        val m = regex.find(headers.toString())
        return m?.groups?.get(1)?.value ?: ""
    }
}
