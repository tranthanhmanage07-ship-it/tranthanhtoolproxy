package com.example.netproxy

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var resetBtn: Button
    private lateinit var infoBtn: Button
    private lateinit var statusTxt: TextView

    private var proxyServer: ProxyServer? = null
    private var apiServer: ApiServer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startBtn = findViewById(R.id.btnStart)
        stopBtn = findViewById(R.id.btnStop)
        resetBtn = findViewById(R.id.btnReset)
        infoBtn = findViewById(R.id.btnInfo)
        statusTxt = findViewById(R.id.txtStatus)

        startBtn.setOnClickListener {
            startServers()
        }
        stopBtn.setOnClickListener {
            stopServers()
        }
        resetBtn.setOnClickListener {
            openMobileDataSettings()
        }
        infoBtn.setOnClickListener {
            updateStatus()
        }
        updateStatus()
    }

    private fun startServers() {
        if (proxyServer == null) {
            proxyServer = ProxyServer(8080)
            proxyServer?.start()
        }
        if (apiServer == null) {
            apiServer = ApiServer(8081, proxyServer!!, this)
            apiServer?.start()
        }
        updateStatus()
    }

    private fun stopServers() {
        CoroutineScope(Dispatchers.IO).launch {
            apiServer?.stop()
            proxyServer?.stop()
        }
        proxyServer = null
        apiServer = null
        updateStatus()
    }

    private fun updateStatus() {
        val ip = NetworkUtil.getLocalIpAddress(this) ?: "unknown"
        val running = proxyServer?.isRunning() == true
        statusTxt.text = "IP: $ip\nProxy: ${if (running) \"ON\" else \"OFF\"}\nAPI: 127.0.0.1:8081"
    }

    private fun openMobileDataSettings() {
        val intent = Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        try {
            startActivity(intent)
        } catch (e: Exception) {
            val i2 = Intent(Settings.ACTION_SETTINGS)
            i2.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(i2)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        CoroutineScope(Dispatchers.IO).launch {
            apiServer?.stop()
            proxyServer?.stop()
        }
    }
}
