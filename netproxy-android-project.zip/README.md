# Network Proxy Utility (Android) - Ready to build
This archive contains the Android Studio project source for the **Network Proxy Utility** (Dark dashboard).
It is intended to be built locally by you (Android Studio on your PC) or via CI (GitHub Actions).

## What is included
- app/src/main/AndroidManifest.xml
- app/build.gradle
- app/src/main/java/com/example/netproxy/MainActivity.kt
- app/src/main/java/com/example/netproxy/ProxyServer.kt
- app/src/main/java/com/example/netproxy/ApiServer.kt (basic NanoHTTPD-based API)
- app/src/main/res/layout/activity_main.xml
- settings.gradle
- build.gradle (project-level)

## How to build (Android Studio)
1. Extract the zip.
2. Open Android Studio -> Open an existing project -> select the extracted folder.
3. Let Gradle sync. Install SDK/NDK if prompted (compileSdk 34).
4. Run on your Android 12 device or emulator (note: toggling mobile data may require ADB).

## How to build via GitHub Actions (automated)
- Create a repository, push this project, and add an Android build workflow.
- Use `react-native-community/android-release` or standard `gradle assembleRelease` in the CI.
- You'll need to provide signing configs for a release build.

## Important notes
- This is a utility app for **local** proxy usage only (127.0.0.1). It does NOT create a public proxy.
- Android 12 restricts programmatic mobile data toggling. The Reset button opens the mobile data settings as fallback.
- The included proxy is a lightweight HTTP forwarder suitable for local testing; it's not production-grade.
